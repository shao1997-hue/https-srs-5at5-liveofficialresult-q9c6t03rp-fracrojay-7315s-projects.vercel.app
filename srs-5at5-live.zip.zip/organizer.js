console.log("SRS 5@5 Organizer starting...");


// =====================================================
// STATE
// =====================================================

const $ = id => document.getElementById(id);

let participants = [];
let raceResults = [];
let refreshTimer = null;
let reloadTimer = null;

const inFlight = new Set();


// =====================================================
// HELPERS
// =====================================================

const keyOf = value => String(value || "").trim().toUpperCase();

function normalizeAgeCategory(value) {
    const c = keyOf(value);
    if (c === "20-29" || c === "30-39" || c === "40-49") return c;
    if (c === "50 & UP" || c === "50+" || c === "50 PLUS" || c === "50 AND UP") return "50 & UP";
    return "";
}

function normalizeGender(value) {
    const g = String(value || "").trim().toLowerCase();
    if (g === "male" || g === "m") return "Male";
    if (g === "female" || g === "f") return "Female";
    return "";
}

function normalizeStatus(value) {
    const s = keyOf(value);
    return ["FINISHED", "DNF", "DNS", "WAITING"].includes(s) ? s : "WAITING";
}

// "25:30" or "1:05:30" -> whole seconds (null if invalid)
function timeToSeconds(value) {
    if (value === null || value === undefined) return null;

    const text = String(value).trim();
    if (!text) return null;

    const raw = text.split(":");
    if (raw.length < 2 || raw.length > 3 || raw.some(p => p.trim() === "")) return null;

    const n = raw.map(Number);
    if (n.some(x => !Number.isFinite(x) || x < 0)) return null;

    if (n.length === 2) {
        if (n[1] >= 60) return null;
        return Math.floor(n[0] * 60 + n[1]);
    }

    if (n[1] >= 60 || n[2] >= 60) return null;
    return Math.floor(n[0] * 3600 + n[1] * 60 + n[2]);
}

// Excel time cells arrive as a fraction of a day (0.0177 = 25:30)
function cellToSeconds(raw) {
    if (typeof raw === "number") {
        return raw > 0 && raw < 1 ? Math.round(raw * 86400) : null;
    }
    return timeToSeconds(raw);
}

// whole seconds -> "25:30" or "1:05:30" (same format the server uses)
function secondsToTime(sec) {
    const p = n => String(n).padStart(2, "0");
    if (sec >= 3600) {
        return Math.floor(sec / 3600) + ":" + p(Math.floor((sec % 3600) / 60)) + ":" + p(sec % 60);
    }
    return p(Math.floor(sec / 60)) + ":" + p(sec % 60);
}

function showMessage(element, message, type) {
    if (!element) return;
    element.textContent = message;
    element.className = "message show " + type;
}

function hideMessage(element) {
    if (!element) return;
    element.textContent = "";
    element.className = "message";
}

function escapeHtml(value) {
    if (value === null || value === undefined) return "";
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function isRaceRunning() {
    return typeof RaceClock !== "undefined" && RaceClock.isRunning();
}

function findParticipantByCode(code) {
    return participants.find(p => keyOf(p.participant_code) === keyOf(code)) || null;
}

function findParticipantsByBib(bib) {
    return participants.filter(p => keyOf(p.bib) === keyOf(bib));
}

// Accepts a bib number (preferred) or a participant code
function lookupParticipant(value) {
    const text = String(value || "").trim();

    if (!text) return { participant: null, error: "" };

    const byBib = findParticipantsByBib(text);

    if (byBib.length === 1) return { participant: byBib[0], error: "" };

    if (byBib.length > 1) {
        return {
            participant: null,
            error: "Bib " + text + " belongs to more than one participant. Use the participant code instead."
        };
    }

    const byCode = findParticipantByCode(text);

    if (byCode) return { participant: byCode, error: "" };

    return { participant: null, error: "No participant found for \"" + text + "\"." };
}

function resultFor(participant) {
    return raceResults.find(r => keyOf(r.participant_code) === keyOf(participant.participant_code)) || null;
}

// Re-use the code already stored on the result row so we never create duplicates
function resultCodeFor(participant) {
    const existing = resultFor(participant);
    return existing ? existing.participant_code : participant.participant_code;
}

function participantLabel(p) {
    return "#" + p.bib + " " + p.participant_name;
}

async function upsertResults(records) {
    const response = await supabaseClient
        .from("race_results")
        .upsert(records, { onConflict: "participant_code" });

    if (response.error) throw response.error;
}


// =====================================================
// LOGIN / SESSION
// =====================================================

async function loginOrganizer() {
    const email = $("loginEmail").value.trim();
    const password = $("loginPassword").value;

    if (!email || !password) {
        showMessage($("loginMessage"), "Please enter your email and password.", "error");
        return;
    }

    const button = $("loginButton");
    button.disabled = true;
    button.textContent = "Logging in...";
    hideMessage($("loginMessage"));

    try {
        const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });
        if (error) throw error;

        if (!data.user || !data.session) {
            throw new Error("Login succeeded but no session was created.");
        }

        showDashboard(data.user);
        await loadAll();
    } catch (error) {
        console.error("Login error:", error);
        showMessage($("loginMessage"), error.message || "Login failed.", "error");
    } finally {
        button.disabled = false;
        button.textContent = "Login";
    }
}

function showDashboard(user) {
    $("loginSection").classList.add("hidden");
    $("dashboardSection").classList.remove("hidden");
    $("userEmail").textContent = "Logged in as: " + (user && user.email ? user.email : "");
}

function showLogin() {
    $("dashboardSection").classList.add("hidden");
    $("loginSection").classList.remove("hidden");
    $("userEmail").textContent = "";
}

async function logoutOrganizer() {
    try {
        const { error } = await supabaseClient.auth.signOut();
        if (error) throw error;

        showLogin();
        $("loginPassword").value = "";
    } catch (error) {
        console.error("Logout error:", error);
    }
}

async function checkExistingSession() {
    try {
        const { data, error } = await supabaseClient.auth.getSession();
        if (error) throw error;

        if (data.session && data.session.user) {
            showDashboard(data.session.user);
            await loadAll();
        } else {
            showLogin();
        }
    } catch (error) {
        console.error("Session check error:", error);
        showLogin();
    }
}

function setupAuthListener() {
    supabaseClient.auth.onAuthStateChange(function (event, session) {
        if (session && session.user) {
            showDashboard(session.user);
        } else {
            showLogin();
        }
    });
}


// =====================================================
// LOAD DATA
// =====================================================

async function loadAll() {
    try {
        const [p, r] = await Promise.all([
            supabaseClient.from("participants").select("*").order("id", { ascending: false }),
            supabaseClient.from("race_results").select("*").order("id", { ascending: false })
        ]);

        if (p.error) throw p.error;
        if (r.error) throw r.error;

        participants = p.data || [];
        raceResults = r.data || [];

        renderLeaderboard();
        renderRecent();
    } catch (error) {
        console.error("Load error:", error);
    }
}

// Several realtime events in a row (e.g. many finishers) -> one reload
function scheduleReload() {
    clearTimeout(reloadTimer);
    reloadTimer = setTimeout(loadAll, 250);
}


// =====================================================
// RACE CLOCK CONTROLS
// =====================================================

function updateClockButtons() {
    const status = typeof RaceClock !== "undefined" ? RaceClock.getState().status : "NOT_STARTED";

    $("startRaceButton").disabled = status !== "NOT_STARTED";
    $("stopClockButton").disabled = status !== "RUNNING";
    $("resetClockButton").disabled = status === "NOT_STARTED";
}

async function clockAction(action) {
    const message = $("clockMessage");
    hideMessage(message);

    if (action === "STOP" &&
        !confirm("Stop the race clock? Tap/bib recording will stop. Existing times are kept.")) {
        return;
    }

    if (action === "RESET" &&
        !confirm("Reset the race clock to zero? Finish times already recorded are kept.")) {
        return;
    }

    const offset = action === "START"
        ? Math.max(0, parseInt($("startOffset").value, 10) || 0)
        : 0;

    ["startRaceButton", "stopClockButton", "resetClockButton"].forEach(id => { $(id).disabled = true; });

    try {
        const { error } = await supabaseClient.rpc("set_race_clock", {
            p_action: action,
            p_offset_seconds: offset
        });
        if (error) throw error;

        await RaceClock.refresh();

        showMessage(
            message,
            action === "START" ? "Race started." : action === "STOP" ? "Clock stopped." : "Clock reset.",
            "success"
        );

        if (action === "START") {
            $("startOffset").value = 0;
            $("finishBib").focus();
        }
    } catch (error) {
        console.error("Clock error:", error);
        showMessage(message, error.message || "Clock action failed.", "error");
    } finally {
        updateClockButtons();
    }
}


// =====================================================
// RECORD FINISH (tap or bib) - the SERVER stamps the time
// =====================================================

async function recordFinish(participant) {
    const code = participant.participant_code;

    if (inFlight.has(code)) return;
    inFlight.add(code);

    const message = $("finishMessage");

    try {
        const { data, error } = await supabaseClient.rpc("record_finish", {
            p_participant_code: code
        });
        if (error) throw error;

        showMessage(
            message,
            "#" + data.bib + "  " + data.participant_name + "  -  " + data.result_time + "  recorded.",
            "success"
        );

        await loadAll();
    } catch (error) {
        console.error("Record finish error:", error);
        showMessage(message, error.message || "Could not record finish.", "error");
    } finally {
        inFlight.delete(code);
    }
}

async function recordFinishFromBib() {
    const input = $("finishBib");
    const message = $("finishMessage");
    const bib = input.value.trim();

    if (!bib) {
        showMessage(message, "Enter a bib number.", "error");
        return;
    }

    const matches = findParticipantsByBib(bib);

    if (!matches.length) {
        showMessage(message, "Bib " + bib + " was not found.", "error");
        input.select();
        return;
    }

    if (matches.length > 1) {
        showMessage(
            message,
            "Bib " + bib + " belongs to more than one participant. Use the Finish button in the list.",
            "error"
        );
        return;
    }

    $("recordFinishButton").disabled = true;
    await recordFinish(matches[0]);
    $("recordFinishButton").disabled = false;

    input.value = "";
    input.focus();
}


// =====================================================
// DELETE PARTICIPANT
// =====================================================

async function deleteParticipant(code) {
    const participant = findParticipantByCode(code);
    if (!participant) return;

    if (!confirm(
        "Delete " + participantLabel(participant) + "?\n\n" +
        "Their result is removed too. This cannot be undone."
    )) {
        return;
    }

    const message = $("listMessage");

    try {
        const existing = resultFor(participant);

        if (existing) {
            const r = await supabaseClient
                .from("race_results")
                .delete()
                .eq("participant_code", existing.participant_code);

            if (r.error) throw r.error;
        }

        const p = await supabaseClient
            .from("participants")
            .delete()
            .eq("participant_code", participant.participant_code)
            .select();

        if (p.error) throw p.error;

        if (!p.data || !p.data.length) {
            throw new Error("The participant was not deleted. Check your permissions.");
        }

        showMessage(message, "Deleted " + participantLabel(participant) + ".", "success");
        await loadAll();
    } catch (error) {
        console.error("Delete participant error:", error);
        showMessage(message, error.message || "Could not delete participant.", "error");
    }
}


// =====================================================
// DOWNLOAD OVERALL RESULTS (EXCEL)
// =====================================================

function downloadResultsExcel() {
    const message = $("listMessage");

    if (typeof XLSX === "undefined") {
        showMessage(message, "Excel library is not loaded.", "error");
        return;
    }

    if (!participants.length) {
        showMessage(message, "There are no participants to export.", "error");
        return;
    }

    const ranked = computeRanked();
    const rows = sortRows(ranked.rows);

    const header = [
        "Overall Position",
        "Gender Position",
        "Age Category Position",
        "BIB",
        "Participant Code",
        "Participant Name",
        "Gender",
        "Age Category",
        "Result Time",
        "Status"
    ];

    const data = rows.map(function (row) {
        const p = row.participant;
        const result = row.result;
        const pos = map => (map.get(row.code) !== undefined ? map.get(row.code) : "");

        return [
            pos(ranked.overall),
            pos(ranked.genderRanks),
            pos(ranked.ageRanks),
            String(p.bib === null || p.bib === undefined ? "" : p.bib),
            p.participant_code,
            p.participant_name,
            row.gender,
            row.ageCategory,
            result && result.result_time ? result.result_time : "",
            result && result.status ? result.status : "WAITING"
        ];
    });

    const sheet = XLSX.utils.aoa_to_sheet([header].concat(data));

    sheet["!cols"] = [
        { wch: 10 }, { wch: 10 }, { wch: 12 }, { wch: 8 }, { wch: 18 },
        { wch: 28 }, { wch: 10 }, { wch: 14 }, { wch: 12 }, { wch: 10 }
    ];

    const book = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(book, sheet, "Results");

    XLSX.writeFile(book, "SRS-5at5-Results-" + new Date().toISOString().slice(0, 10) + ".xlsx");

    showMessage(message, "Downloaded results for " + data.length + " participant(s).", "success");
}


// =====================================================
// EMAIL RESULTS BACKUP (Excel sent to your email)
// =====================================================

async function emailResultsBackup() {
    const message = $("listMessage");
    const button = $("emailResultsButton");

    button.disabled = true;
    button.textContent = "Sending...";
    hideMessage(message);

    try {
        const { data } = await supabaseClient.auth.getSession();
        const token = data && data.session ? data.session.access_token : null;

        if (!token) throw new Error("Please log in again.");

        const response = await fetch("/api/send-backup", {
            method: "POST",
            headers: { Authorization: "Bearer " + token }
        });

        let result = {};

        try { result = await response.json(); } catch (e) {}

        if (!response.ok) {
            throw new Error(result.error || "Could not send the backup email (error " + response.status + ").");
        }

        showMessage(
            message,
            "Backup emailed to " + result.sentTo + " (" + result.participants + " participants). Check your inbox.",
            "success"
        );
    } catch (error) {
        console.error("Email backup error:", error);
        showMessage(message, error.message || "Could not send the backup email.", "error");
    } finally {
        button.disabled = false;
        button.textContent = "Email Results Backup";
    }
}


// =====================================================
// EDIT / CLEAR RESULTS
// =====================================================

function updateResultWho() {
    const { participant, error } = lookupParticipant($("resultParticipantCode").value);

    if (!participant) {
        $("resultWho").textContent = error;
        return;
    }

    const result = resultFor(participant);

    $("resultWho").textContent =
        "Editing: " + participantLabel(participant) +
        (result && result.status !== "WAITING"
            ? " (current: " + (result.result_time || "-") + ", " + result.status + ")"
            : "");
}

function editResult(code) {
    const participant = findParticipantByCode(code);
    if (!participant) return;

    const result = resultFor(participant);

    $("resultParticipantCode").value =
        findParticipantsByBib(participant.bib).length === 1 ? participant.bib : participant.participant_code;
    $("resultTime").value = result && result.result_time ? result.result_time : "";
    $("resultStatus").value =
        result && result.status && result.status !== "WAITING" ? result.status : "FINISHED";

    hideMessage($("resultMessage"));
    updateResultWho();

    $("resultForm").scrollIntoView({ behavior: "smooth", block: "center" });
    $("resultTime").focus();
}

async function clearResult(code) {
    const participant = findParticipantByCode(code);
    if (!participant) return;

    if (!confirm("Clear the result for " + participantLabel(participant) + "? They go back to waiting.")) {
        return;
    }

    try {
        await upsertResults([{
            participant_code: resultCodeFor(participant),
            result_time: "",
            sort_time: null,
            status: "WAITING",
            finish_ms: null,
            source: "MANUAL",
            updated_at: new Date().toISOString()
        }]);

        showMessage($("finishMessage"), "Result cleared for " + participantLabel(participant) + ".", "success");
        await loadAll();
    } catch (error) {
        console.error("Clear result error:", error);
        showMessage($("finishMessage"), error.message || "Could not clear result.", "error");
    }
}

// Manual add / edit
async function saveResult() {
    const message = $("resultMessage");
    const entered = $("resultParticipantCode").value.trim();
    const time = $("resultTime").value.trim();
    const status = normalizeStatus($("resultStatus").value);

    if (!entered) {
        showMessage(message, "Please enter the bib number.", "error");
        return;
    }

    const { participant, error: lookupError } = lookupParticipant(entered);

    if (!participant) {
        showMessage(message, lookupError, "error");
        return;
    }

    let seconds = null;

    if (status === "FINISHED") {
        seconds = timeToSeconds(time);

        if (seconds === null) {
            showMessage(message, "Invalid result time. Use MM:SS or HH:MM:SS.", "error");
            return;
        }
    }

    const button = $("saveResultButton");
    button.disabled = true;
    button.textContent = "Saving...";

    try {
        await upsertResults([{
            participant_code: resultCodeFor(participant),
            result_time: seconds === null ? "" : secondsToTime(seconds),
            sort_time: seconds,
            status: status,
            finish_ms: null,
            source: "MANUAL",
            updated_at: new Date().toISOString()
        }]);

        showMessage(message, "Result saved for " + participantLabel(participant) + ".", "success");

        $("resultParticipantCode").value = "";
        $("resultTime").value = "";
        $("resultStatus").value = "FINISHED";
        updateResultWho();

        await loadAll();
    } catch (error) {
        console.error("Save result error:", error);
        showMessage(message, error.message || "Unable to save result.", "error");
    } finally {
        button.disabled = false;
        button.textContent = "Save Result";
    }
}


// =====================================================
// ADD PARTICIPANT
// =====================================================

async function addParticipant() {
    const message = $("participantMessage");

    const code = $("participantCode").value.trim();
    const bib = $("participantBib").value.trim();
    const name = $("participantName").value.trim();
    const gender = normalizeGender($("participantGender").value);
    const ageCategory = normalizeAgeCategory($("participantAgeCategory").value);

    if (!code || !bib || !name || !gender || !ageCategory) {
        showMessage(message, "Please complete all participant fields.", "error");
        return;
    }

    const button = $("addParticipantButton");
    button.disabled = true;
    button.textContent = "Saving...";

    try {
        const { error } = await supabaseClient.from("participants").insert([{
            participant_code: code,
            bib: bib,
            participant_name: name,
            gender: gender,
            age_category: ageCategory
        }]);
        if (error) throw error;

        showMessage(message, "Participant saved successfully.", "success");

        $("participantCode").value = "";
        $("participantBib").value = "";
        $("participantName").value = "";
        $("participantGender").value = "";
        $("participantAgeCategory").value = "";

        await loadAll();
    } catch (error) {
        console.error("Add participant error:", error);
        showMessage(message, error.message || "Unable to save participant.", "error");
    } finally {
        button.disabled = false;
        button.textContent = "Save Participant";
    }
}


// =====================================================
// EXCEL UPLOADS
// =====================================================

async function readSheet(fileInput) {
    if (typeof XLSX === "undefined") {
        throw new Error("Excel library is not loaded.");
    }

    const buffer = await fileInput.files[0].arrayBuffer();
    const workbook = XLSX.read(buffer, { type: "array" });
    const rows = XLSX.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]], { defval: "" });

    if (!rows.length) throw new Error("The Excel file is empty.");
    return rows;
}

function pick(row, names) {
    for (const name of names) {
        if (row[name] !== undefined && row[name] !== "") return row[name];
    }
    return "";
}

async function uploadParticipantsExcel() {
    const message = $("participantUploadMessage");
    const input = $("participantExcel");

    if (!input.files.length) {
        showMessage(message, "Please select an Excel file first.", "error");
        return;
    }

    const button = $("uploadParticipantsButton");
    button.disabled = true;
    button.textContent = "Uploading...";

    try {
        const data = await readSheet(input);

        const records = data.map(function (row, index) {
            const record = {
                participant_code: String(pick(row, ["participant_code", "Participant_Code", "Participant Code"])).trim(),
                bib: String(pick(row, ["bib", "BIB", "Bib"])).trim(),
                participant_name: String(pick(row, ["participant_name", "Participant_Name", "Participant Name"])).trim(),
                gender: normalizeGender(pick(row, ["gender", "Gender"])),
                age_category: normalizeAgeCategory(pick(row, ["age_category", "Age_Category", "Age Category"]))
            };

            if (!record.participant_code || !record.bib || !record.participant_name ||
                !record.gender || !record.age_category) {
                throw new Error(
                    "Invalid participant data on Excel row " + (index + 2) +
                    ". Required: participant_code, bib, participant_name, gender, age_category."
                );
            }

            return record;
        });

        const { error } = await supabaseClient
            .from("participants")
            .upsert(records, { onConflict: "participant_code" });
        if (error) throw error;

        showMessage(message, records.length + " participant(s) uploaded successfully.", "success");
        input.value = "";

        await loadAll();
    } catch (error) {
        console.error("Participant Excel upload error:", error);
        showMessage(message, error.message || "Unable to upload participant Excel file.", "error");
    } finally {
        button.disabled = false;
        button.textContent = "Upload Participants";
    }
}

async function uploadResultsExcel() {
    const message = $("resultUploadMessage");
    const input = $("resultExcel");

    if (!input.files.length) {
        showMessage(message, "Please select a result Excel file first.", "error");
        return;
    }

    const button = $("uploadResultsButton");
    button.disabled = true;
    button.textContent = "Uploading...";

    try {
        const data = await readSheet(input);

        const records = data.map(function (row, index) {
            const rowNumber = index + 2;
            const code = String(pick(row, ["participant_code", "Participant_Code", "Participant Code"])).trim();
            const status = normalizeStatus(pick(row, ["status", "Status"]));

            if (!code) throw new Error("Missing participant code on row " + rowNumber);

            const participant = findParticipantByCode(code);
            if (!participant) {
                throw new Error("Participant code " + code + " was not found on row " + rowNumber);
            }

            let seconds = null;

            if (status === "FINISHED") {
                seconds = cellToSeconds(pick(row, ["result_time", "Result_Time", "Result Time"]));
                if (seconds === null) throw new Error("Invalid result time on row " + rowNumber);
            }

            return {
                participant_code: resultCodeFor(participant),
                result_time: seconds === null ? "" : secondsToTime(seconds),
                sort_time: seconds,
                status: status,
                finish_ms: null,
                source: "UPLOAD",
                updated_at: new Date().toISOString()
            };
        });

        await upsertResults(records);

        showMessage(message, records.length + " result(s) uploaded successfully.", "success");
        input.value = "";

        await loadAll();
    } catch (error) {
        console.error("Result Excel upload error:", error);
        showMessage(message, error.message || "Unable to upload result Excel file.", "error");
    } finally {
        button.disabled = false;
        button.textContent = "Upload Results";
    }
}


// =====================================================
// RENDER
// =====================================================

function assignRanks(rows) {
    const sorted = rows
        .filter(r => r.sortTime !== null)
        .sort((a, b) => a.sortTime - b.sortTime);

    const ranks = new Map();
    let previous = null;
    let rank = 0;

    sorted.forEach(function (row, index) {
        if (previous === null || row.sortTime !== previous) rank = index + 1;
        ranks.set(row.code, rank);
        previous = row.sortTime;
    });

    return ranks;
}

function getSortTime(result) {
    if (!result || result.status !== "FINISHED") return null;

    let t;

    if (result.sort_time !== null && result.sort_time !== undefined && result.sort_time !== "") {
        t = Number(result.sort_time);
    } else {
        t = timeToSeconds(result.result_time);
    }

    return Number.isFinite(t) ? t : null;
}

function computeRanked() {
    const resultMap = new Map(raceResults.map(r => [keyOf(r.participant_code), r]));

    const rows = participants.map(function (p) {
        const result = resultMap.get(keyOf(p.participant_code)) || null;

        return {
            participant: p,
            code: p.participant_code,
            result: result,
            gender: normalizeGender(p.gender),
            ageCategory: normalizeAgeCategory(p.age_category),
            sortTime: getSortTime(result)
        };
    });

    const overall = assignRanks(rows);
    const genderRanks = new Map();
    const ageRanks = new Map();

    ["Male", "Female"].forEach(function (g) {
        assignRanks(rows.filter(r => r.gender === g)).forEach((v, k) => genderRanks.set(k, v));
    });

    const groups = {};

    rows.forEach(function (r) {
        if (r.gender && r.ageCategory) {
            const key = r.gender + "|" + r.ageCategory;
            (groups[key] = groups[key] || []).push(r);
        }
    });

    Object.keys(groups).forEach(function (key) {
        assignRanks(groups[key]).forEach((v, k) => ageRanks.set(k, v));
    });

    return { rows: rows, overall: overall, genderRanks: genderRanks, ageRanks: ageRanks };
}

// finished first (fastest first), then everyone else by name
function sortRows(rows) {
    rows.sort(function (a, b) {
        if (a.sortTime !== null && b.sortTime !== null) return a.sortTime - b.sortTime;
        if (a.sortTime !== null) return -1;
        if (b.sortTime !== null) return 1;
        return String(a.participant.participant_name).localeCompare(String(b.participant.participant_name));
    });

    return rows;
}

function renderLeaderboard() {
    const body = $("resultsTableBody");
    if (!body) return;

    const ranked = computeRanked();
    const overall = ranked.overall;
    const genderRanks = ranked.genderRanks;
    const ageRanks = ranked.ageRanks;

    let rows = ranked.rows;

    // ---- filters ----
    const genderFilter = $("organizerGenderFilter").value;
    const ageFilter = $("organizerAgeCategoryFilter").value;
    const search = keyOf($("organizerSearch").value);

    rows = rows.filter(function (r) {
        if (genderFilter && r.gender !== genderFilter) return false;
        if (ageFilter && r.ageCategory !== ageFilter) return false;

        if (search) {
            const haystack = keyOf(
                r.participant.bib + " " + r.participant.participant_code + " " + r.participant.participant_name
            );
            if (haystack.indexOf(search) === -1) return false;
        }

        return true;
    });

    sortRows(rows);

    // ---- html ----
    const running = isRaceRunning();

    let html = rows.map(function (row) {
        const p = row.participant;
        const result = row.result;
        const rawStatus = result && result.status ? result.status : "WAITING";
        const status = rawStatus === "WAITING" && running ? "RUNNING" : rawStatus;
        const code = escapeHtml(p.participant_code);

        let actions = "";

        if (rawStatus !== "FINISHED") {
            actions += '<button class="btn-success" data-action="finish" data-code="' + code + '">Finish</button>';
        }

        actions += '<button class="btn-secondary" data-action="edit" data-code="' + code + '">Edit</button>';

        if (result && (rawStatus !== "WAITING" || result.result_time)) {
            actions += '<button class="btn-danger" data-action="clear" data-code="' + code + '">Clear</button>';
        }

        actions += '<button class="btn-delete" data-action="delete" data-code="' + code + '">Delete</button>';

        const rank = value => (value !== undefined ? value : "-");

        return "<tr>" +
            "<td>" + rank(overall.get(row.code)) + "</td>" +
            "<td>" + rank(genderRanks.get(row.code)) + "</td>" +
            "<td>" + rank(ageRanks.get(row.code)) + "</td>" +
            "<td>" + escapeHtml(p.bib) + "</td>" +
            "<td>" + code + "</td>" +
            "<td>" + escapeHtml(p.participant_name) + "</td>" +
            "<td>" + escapeHtml(row.gender) + "</td>" +
            "<td>" + escapeHtml(row.ageCategory) + "</td>" +
            "<td>" + escapeHtml(result && result.result_time ? result.result_time : "-") + "</td>" +
            '<td class="status-' + status.toLowerCase() + '">' + escapeHtml(status) + "</td>" +
            '<td class="row-actions">' + actions + "</td>" +
            "</tr>";
    }).join("");

    if (!html) {
        html = '<tr><td colspan="11" style="text-align:center;">No participants found.</td></tr>';
    }

    body.innerHTML = html;
}

function renderRecent() {
    const box = $("recentFinishes");
    if (!box) return;

    const byCode = new Map(participants.map(p => [keyOf(p.participant_code), p]));

    const recent = raceResults
        .filter(r => r.status === "FINISHED" && r.updated_at)
        .sort((a, b) => String(b.updated_at).localeCompare(String(a.updated_at)))
        .slice(0, 8);

    if (!recent.length) {
        box.innerHTML = '<div class="category-note">No finishes recorded yet.</div>';
        return;
    }

    box.innerHTML = recent.map(function (r) {
        const p = byCode.get(keyOf(r.participant_code));
        const label = p ? participantLabel(p) : r.participant_code;
        const code = escapeHtml(r.participant_code);

        return '<div class="recent-item">' +
            "<div><strong>" + escapeHtml(label) + "</strong> &mdash; " + escapeHtml(r.result_time) + "</div>" +
            '<div class="row-actions">' +
            '<button class="btn-secondary" data-action="edit" data-code="' + code + '">Edit</button>' +
            '<button class="btn-danger" data-action="clear" data-code="' + code + '">Undo</button>' +
            "</div></div>";
    }).join("");
}


// =====================================================
// EVENTS
// =====================================================

function handleRowAction(event) {
    const button = event.target.closest("button[data-action]");
    if (!button) return;

    const code = button.dataset.code;
    const action = button.dataset.action;

    if (action === "finish") {
        const p = findParticipantByCode(code);
        if (p) recordFinish(p);
    } else if (action === "edit") {
        editResult(code);
    } else if (action === "clear") {
        clearResult(code);
    } else if (action === "delete") {
        deleteParticipant(code);
    }
}

function bind(id, eventName, handler) {
    const el = $(id);
    if (el) el.addEventListener(eventName, handler);
}

bind("loginButton", "click", loginOrganizer);
bind("loginForm", "submit", function (e) { e.preventDefault(); loginOrganizer(); });
bind("logoutButton", "click", logoutOrganizer);

bind("addParticipantButton", "click", addParticipant);
bind("uploadParticipantsButton", "click", uploadParticipantsExcel);

bind("saveResultButton", "click", saveResult);
bind("downloadResultsButton", "click", downloadResultsExcel);
bind("emailResultsButton", "click", emailResultsBackup);
bind("uploadResultsButton", "click", uploadResultsExcel);
bind("resultParticipantCode", "input", updateResultWho);

bind("startRaceButton", "click", () => clockAction("START"));
bind("stopClockButton", "click", () => clockAction("STOP"));
bind("resetClockButton", "click", () => clockAction("RESET"));

bind("recordFinishButton", "click", recordFinishFromBib);
bind("finishBib", "keydown", function (e) {
    if (e.key === "Enter") {
        e.preventDefault();
        recordFinishFromBib();
    }
});

bind("resultsTableBody", "click", handleRowAction);
bind("recentFinishes", "click", handleRowAction);

bind("organizerGenderFilter", "change", renderLeaderboard);
bind("organizerAgeCategoryFilter", "change", renderLeaderboard);
bind("organizerSearch", "input", renderLeaderboard);

bind("clearOrganizerFilters", "click", function () {
    $("organizerGenderFilter").value = "";
    $("organizerAgeCategoryFilter").value = "";
    $("organizerSearch").value = "";
    renderLeaderboard();
});


// =====================================================
// REALTIME + POLLING
// =====================================================

function setupRealtime() {
    try {
        ["participants", "race_results"].forEach(function (table) {
            supabaseClient
                .channel("organizer-" + table)
                .on("postgres_changes", { event: "*", schema: "public", table: table }, scheduleReload)
                .subscribe();
        });
    } catch (error) {
        console.error("Realtime setup error:", error);
    }
}

function startPolling() {
    if (refreshTimer) clearInterval(refreshTimer);

    refreshTimer = setInterval(async function () {
        try {
            const { data } = await supabaseClient.auth.getSession();
            if (data && data.session) await loadAll();
        } catch (error) {
            console.error("Polling error:", error);
        }
    }, 10000);
}


// =====================================================
// START
// =====================================================

async function startOrganizer() {
    if (typeof supabaseClient === "undefined" || !supabaseClient) {
        console.error("Supabase client is not available.");
        return;
    }

    if (typeof RaceClock !== "undefined") {
        RaceClock.onChange(function () {
            updateClockButtons();
            renderLeaderboard();
        });
        RaceClock.init();
    }

    updateClockButtons();

    setupAuthListener();
    await checkExistingSession();
    setupRealtime();
    startPolling();
}

startOrganizer();