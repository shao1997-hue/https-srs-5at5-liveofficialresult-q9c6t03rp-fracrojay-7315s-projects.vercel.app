// ============================================================
// SRS 5@5 - EMAIL RESULTS BACKUP (Vercel serverless function)
//
// The organizer page calls this with the organizer's login token.
// It reads the participants + results, builds an Excel file and
// emails it to you through Resend (resend.com).
//
// Vercel environment variables:
//   RESEND_API_KEY      (required)  your Resend API key (starts with re_)
//   BACKUP_EMAIL_TO     (optional)  where to send; defaults to the organizer's login email
//   BACKUP_EMAIL_FROM   (optional)  defaults to "SRS 5@5 Results <onboarding@resend.dev>"
// ============================================================

const XLSX = require("xlsx");

const SUPABASE_URL = process.env.SUPABASE_URL || "https://locqijalffbyxdlbnogb.supabase.co";
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || "sb_publishable_rEs_ID9sWnk7BP6oeFzamA_PRASv3_3";


// ---------- helpers (same rules as the organizer page) ----------

const keyOf = value => String(value || "").trim().toUpperCase();

function normalizeGender(value) {
    const g = String(value || "").trim().toLowerCase();
    if (g === "male" || g === "m") return "Male";
    if (g === "female" || g === "f") return "Female";
    return "";
}

function normalizeAgeCategory(value) {
    const c = keyOf(value);
    if (c === "20-29" || c === "30-39" || c === "40-49") return c;
    if (c === "50 & UP" || c === "50+" || c === "50 PLUS" || c === "50 AND UP") return "50 & UP";
    return "";
}

function timeToSeconds(value) {
    if (value === null || value === undefined) return null;

    const text = String(value).trim();
    if (!text) return null;

    const raw = text.split(":");
    if (raw.length < 2 || raw.length > 3 || raw.some(p => p.trim() === "")) return null;

    const n = raw.map(Number);
    if (n.some(x => !Number.isFinite(x) || x < 0)) return null;

    return Math.floor(n.length === 2 ? n[0] * 60 + n[1] : n[0] * 3600 + n[1] * 60 + n[2]);
}

function getSortTime(result) {
    if (!result || result.status !== "FINISHED") return null;

    let t;

    if (result.sort_time !== null && result.sort_time !== undefined && result.sort_time !== "") {
        t = Number(result.sort_time);
    } else {
        t = timeToSeconds(result.result_time);
    }

    return Number.isFinite(t) ? t : null;
}

// 1, 1, 3 style ranking (ties share a position)
function assignRanks(rows) {
    const sorted = rows
        .filter(r => r.sortTime !== null)
        .sort((a, b) => a.sortTime - b.sortTime);

    const ranks = new Map();
    let previous = null;
    let rank = 0;

    sorted.forEach(function (row, index) {
        if (previous === null || row.sortTime !== previous) rank = index + 1;
        ranks.set(row.code, rank);
        previous = row.sortTime;
    });

    return ranks;
}

// Kuwait time for the file name and email text
function kuwaitStamp(date) {
    const parts = new Intl.DateTimeFormat("en-GB", {
        timeZone: "Asia/Kuwait",
        year: "numeric", month: "2-digit", day: "2-digit",
        hour: "2-digit", minute: "2-digit", hourCycle: "h23"
    }).formatToParts(date);

    const get = type => parts.find(p => p.type === type).value;

    return {
        file: get("year") + "-" + get("month") + "-" + get("day") + "_" + get("hour") + get("minute"),
        pretty: get("day") + "/" + get("month") + "/" + get("year") + " " + get("hour") + ":" + get("minute")
    };
}


// ---------- read data from Supabase as the logged-in organizer ----------

async function fetchAll(table, token) {
    const rows = [];
    const pageSize = 1000;

    for (let offset = 0; ; offset += pageSize) {
        const response = await fetch(
            SUPABASE_URL + "/rest/v1/" + table +
            "?select=*&order=id.asc&limit=" + pageSize + "&offset=" + offset,
            { headers: { apikey: SUPABASE_ANON_KEY, Authorization: "Bearer " + token } }
        );

        if (!response.ok) {
            throw new Error("Could not read " + table + " (error " + response.status + ").");
        }

        const page = await response.json();
        rows.push(...page);

        if (page.length < pageSize) break;
    }

    return rows;
}


// ---------- build the Excel file ----------

function buildWorkbook(participants, results) {
    const resultMap = new Map(results.map(r => [keyOf(r.participant_code), r]));

    const rows = participants.map(function (p) {
        const result = resultMap.get(keyOf(p.participant_code)) || null;

        return {
            participant: p,
            code: p.participant_code,
            result: result,
            gender: normalizeGender(p.gender),
            ageCategory: normalizeAgeCategory(p.age_category),
            sortTime: getSortTime(result)
        };
    });

    const overall = assignRanks(rows);
    const genderRanks = new Map();
    const ageRanks = new Map();

    ["Male", "Female"].forEach(function (g) {
        assignRanks(rows.filter(r => r.gender === g)).forEach((v, k) => genderRanks.set(k, v));
    });

    const groups = {};

    rows.forEach(function (r) {
        if (r.gender && r.ageCategory) {
            const key = r.gender + "|" + r.ageCategory;
            (groups[key] = groups[key] || []).push(r);
        }
    });

    Object.keys(groups).forEach(function (key) {
        assignRanks(groups[key]).forEach((v, k) => ageRanks.set(k, v));
    });

    // finished first (fastest first), then everyone else by name
    rows.sort(function (a, b) {
        if (a.sortTime !== null && b.sortTime !== null) return a.sortTime - b.sortTime;
        if (a.sortTime !== null) return -1;
        if (b.sortTime !== null) return 1;
        return String(a.participant.participant_name).localeCompare(String(b.participant.participant_name));
    });

    const header = [
        "Overall Position", "Gender Position", "Age Category Position",
        "BIB", "Participant Code", "Participant Name",
        "Gender", "Age Category", "Result Time", "Status"
    ];

    const pos = (map, code) => (map.get(code) !== undefined ? map.get(code) : "");

    const data = rows.map(row => [
        pos(overall, row.code),
        pos(genderRanks, row.code),
        pos(ageRanks, row.code),
        String(row.participant.bib === null || row.participant.bib === undefined ? "" : row.participant.bib),
        row.participant.participant_code,
        row.participant.participant_name,
        row.gender,
        row.ageCategory,
        row.result && row.result.result_time ? row.result.result_time : "",
        row.result && row.result.status ? row.result.status : "WAITING"
    ]);

    const sheet = XLSX.utils.aoa_to_sheet([header].concat(data));

    sheet["!cols"] = [
        { wch: 10 }, { wch: 10 }, { wch: 12 }, { wch: 8 }, { wch: 18 },
        { wch: 28 }, { wch: 10 }, { wch: 14 }, { wch: 12 }, { wch: 10 }
    ];

    const book = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(book, sheet, "Results");

    const count = status => rows.filter(r => (r.result && r.result.status ? r.result.status : "WAITING") === status).length;

    return {
        buffer: XLSX.write(book, { type: "buffer", bookType: "xlsx" }),
        counts: {
            total: rows.length,
            finished: count("FINISHED"),
            dnf: count("DNF"),
            dns: count("DNS"),
            waiting: count("WAITING")
        }
    };
}


// ---------- the endpoint ----------

module.exports = async function handler(req, res) {
    res.setHeader("Cache-Control", "no-store");

    if (req.method !== "POST") {
        res.setHeader("Allow", "POST");
        return res.status(405).json({ error: "Use POST." });
    }

    try {
        const apiKey = process.env.RESEND_API_KEY;

        if (!apiKey) {
            return res.status(500).json({ error: "RESEND_API_KEY is not set in Vercel yet." });
        }

        // only a logged-in organizer may use this
        const header = String(req.headers.authorization || "");
        const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";

        if (!token) {
            return res.status(401).json({ error: "Please log in as organizer first." });
        }

        const userResponse = await fetch(SUPABASE_URL + "/auth/v1/user", {
            headers: { apikey: SUPABASE_ANON_KEY, Authorization: "Bearer " + token }
        });

        if (!userResponse.ok) {
            return res.status(401).json({ error: "Your login expired. Please log in again." });
        }

        const user = await userResponse.json();
        const to = process.env.BACKUP_EMAIL_TO || user.email;

        if (!to) {
            return res.status(500).json({ error: "No email address to send to. Set BACKUP_EMAIL_TO in Vercel." });
        }

        const [participants, results] = await Promise.all([
            fetchAll("participants", token),
            fetchAll("race_results", token)
        ]);

        if (!participants.length) {
            return res.status(400).json({ error: "There are no participants to back up yet." });
        }

        const { buffer, counts } = buildWorkbook(participants, results);
        const stamp = kuwaitStamp(new Date());
        const filename = "SRS-5at5-Results-Backup-" + stamp.file + ".xlsx";

        const text =
            "SRS 5@5 - results backup\n" +
            "Created: " + stamp.pretty + " (Kuwait time)\n\n" +
            "Participants: " + counts.total + "\n" +
            "Finished: " + counts.finished + "\n" +
            "DNF: " + counts.dnf + "\n" +
            "DNS: " + counts.dns + "\n" +
            "Still waiting: " + counts.waiting + "\n\n" +
            "The full results are attached as an Excel file.";

        const emailResponse = await fetch("https://api.resend.com/emails", {
            method: "POST",
            headers: {
                Authorization: "Bearer " + apiKey,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                from: process.env.BACKUP_EMAIL_FROM || "SRS 5@5 Results <onboarding@resend.dev>",
                to: [to],
                subject: "SRS 5@5 results backup - " + stamp.pretty,
                text: text,
                attachments: [{ filename: filename, content: buffer.toString("base64") }]
            })
        });

        const emailResult = await emailResponse.json().catch(() => ({}));

        if (!emailResponse.ok) {
            throw new Error(emailResult.message || "The email service refused the request.");
        }

        return res.status(200).json({
            ok: true,
            sentTo: to,
            participants: counts.total,
            file: filename
        });
    } catch (error) {
        console.error("Backup email error:", error);
        return res.status(500).json({ error: error.message || "Could not send the backup." });
    }
};