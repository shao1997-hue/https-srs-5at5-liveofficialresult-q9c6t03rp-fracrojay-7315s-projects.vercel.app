console.log("SRS 5@5 spectator starting...");


// =====================================================
// DATA
// =====================================================

let participants = [];
let raceResults = [];

let refreshTimer = null;
let reloadTimer = null;
let loadCounter = 0;
let appliedLoad = 0;


// =====================================================
// HELPERS
// =====================================================

const keyOf = value => String(value || "").trim().toUpperCase();

function normalizeGender(value) {
    const g = String(value || "").trim().toLowerCase();
    if (g === "male" || g === "m") return "Male";
    if (g === "female" || g === "f") return "Female";
    return "";
}

function normalizeStatus(value) {
    const s = keyOf(value);
    return ["FINISHED", "DNF", "DNS", "WAITING"].includes(s) ? s : "WAITING";
}

function timeToSeconds(value) {
    if (value === null || value === undefined) return null;

    const text = String(value).trim();
    if (!text) return null;

    const raw = text.split(":");
    if (raw.length < 2 || raw.length > 3 || raw.some(p => p.trim() === "")) return null;

    const n = raw.map(Number);
    if (n.some(x => !Number.isFinite(x) || x < 0)) return null;

    return Math.floor(n.length === 2 ? n[0] * 60 + n[1] : n[0] * 3600 + n[1] * 60 + n[2]);
}

function getSortTime(result, status) {
    if (!result || status !== "FINISHED") return null;

    let t;

    if (result.sort_time !== null && result.sort_time !== undefined && result.sort_time !== "") {
        t = Number(result.sort_time);
    } else {
        t = timeToSeconds(result.result_time);
    }

    return Number.isFinite(t) ? t : null;
}

function escapeHtml(value) {
    if (value === null || value === undefined) return "";
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function isRaceRunning() {
    return typeof RaceClock !== "undefined" && RaceClock.isRunning();
}


// =====================================================
// LOAD DATA
// =====================================================

async function loadLeaderboardData() {
    const myLoad = ++loadCounter;

    try {
        const [p, r] = await Promise.all([
            supabaseClient.from("participants").select("*").order("id", { ascending: true }),
            supabaseClient.from("race_results").select("*")
        ]);

        if (p.error) throw p.error;
        if (r.error) throw r.error;

        // Ignore a slow, older response that finished after a newer one
        if (myLoad < appliedLoad) return;
        appliedLoad = myLoad;

        participants = p.data || [];
        raceResults = r.data || [];

        renderLeaderboards();
    } catch (error) {
        console.error("Leaderboard loading error:", error);
    }
}

// Many realtime events in a row -> one reload
function scheduleReload() {
    clearTimeout(reloadTimer);
    reloadTimer = setTimeout(loadLeaderboardData, 250);
}


// =====================================================
// BUILD + RANK
// =====================================================

function buildRows() {
    const resultMap = new Map(raceResults.map(r => [keyOf(r.participant_code), r]));

    return participants.map(function (participant) {
        const result = resultMap.get(keyOf(participant.participant_code)) || null;
        const status = result && result.status ? normalizeStatus(result.status) : "WAITING";

        return {
            participant: participant,
            result: result,
            gender: normalizeGender(participant.gender),
            status: status,
            sortTime: getSortTime(result, status)
        };
    });
}

function createRanks(rows) {
    const finished = rows
        .filter(r => r.sortTime !== null)
        .sort((a, b) => a.sortTime - b.sortTime);

    const ranks = new Map();
    let previous = null;
    let rank = 0;

    finished.forEach(function (row, index) {
        if (previous === null || row.sortTime !== previous) rank = index + 1;
        ranks.set(keyOf(row.participant.participant_code), rank);
        previous = row.sortTime;
    });

    return ranks;
}


// =====================================================
// RENDER
// =====================================================

function renderGenderLeaderboard(gender, bodyId, countId, allRows) {
    const body = document.getElementById(bodyId);
    const count = document.getElementById(countId);

    if (!body) return;

    const rows = allRows.filter(r => r.gender === gender);

    if (count) {
        count.textContent = rows.length + (rows.length === 1 ? " participant" : " participants");
    }

    const ranks = createRanks(rows);
    const running = isRaceRunning();

    // Finished first (fastest first), everyone else alphabetical
    rows.sort(function (a, b) {
        if (a.sortTime !== null && b.sortTime !== null) return a.sortTime - b.sortTime;
        if (a.sortTime !== null) return -1;
        if (b.sortTime !== null) return 1;
        return String(a.participant.participant_name || "")
            .localeCompare(String(b.participant.participant_name || ""));
    });

    let html = rows.map(function (row) {
        const rank = ranks.get(keyOf(row.participant.participant_code));
        const status = row.status === "WAITING" && running ? "RUNNING" : row.status;

        return "<tr>" +
            '<td class="rank">' + (rank !== undefined ? rank : "-") + "</td>" +
            "<td>" + escapeHtml(row.participant.bib) + "</td>" +
            "<td>" + escapeHtml(row.participant.participant_name) + "</td>" +
            "<td>" + escapeHtml(row.result && row.result.result_time ? row.result.result_time : "-") + "</td>" +
            '<td class="' + status.toLowerCase() + '">' + escapeHtml(status) + "</td>" +
            "</tr>";
    }).join("");

    if (!html) {
        html = '<tr><td colspan="5" class="empty">No participants found.</td></tr>';
    }

    body.innerHTML = html;
}

function renderLeaderboards() {
    const rows = buildRows();

    renderGenderLeaderboard("Male", "maleLeaderboardBody", "maleCount", rows);
    renderGenderLeaderboard("Female", "femaleLeaderboardBody", "femaleCount", rows);

    const updated = document.getElementById("lastUpdated");

    if (updated) {
        updated.textContent = "Last updated: " + new Date().toLocaleTimeString();
    }
}


// =====================================================
// REALTIME + POLLING
// =====================================================

function setupRealtime() {
    try {
        ["participants", "race_results"].forEach(function (table) {
            supabaseClient
                .channel("public-" + table)
                .on("postgres_changes", { event: "*", schema: "public", table: table }, scheduleReload)
                .subscribe(function (status) {
                    console.log(table + " realtime status:", status);
                });
        });
    } catch (error) {
        console.error("Realtime setup error:", error);
    }
}

function startPolling() {
    if (refreshTimer) clearInterval(refreshTimer);
    refreshTimer = setInterval(loadLeaderboardData, 5000);
}


// =====================================================
// START
// =====================================================

async function startSpectator() {
    if (typeof supabaseClient === "undefined" || !supabaseClient) {
        console.error("Supabase client is not available.");
        return;
    }

    // Show "RUNNING" instead of "WAITING" as soon as the clock starts/stops
    if (typeof RaceClock !== "undefined") {
        RaceClock.onChange(renderLeaderboards);
        RaceClock.init();
    }

    await loadLeaderboardData();

    setupRealtime();
    startPolling();
}

startSpectator();