// ============================================================
// SRS 5@5 LIVE LEADERBOARD
// SUPABASE CONFIGURATION
// ============================================================

const SUPABASE_URL =
    "https://locqijalffbyxdlbnogb.supabase.co";

const SUPABASE_ANON_KEY =
    "sb_publishable_rEs_ID9sWnk7BP6oeFzamA_PRASv3_3";


// ============================================================
// CREATE SUPABASE CLIENT
// ============================================================

const supabaseClient =
    window.supabase.createClient(
        SUPABASE_URL,
        SUPABASE_ANON_KEY
    );


// ============================================================
// CONNECTION MESSAGE
// ============================================================

console.log(
    "SRS 5@5 Supabase client initialized successfully."
);

console.log(
    "Supabase URL:",
    SUPABASE_URL
);