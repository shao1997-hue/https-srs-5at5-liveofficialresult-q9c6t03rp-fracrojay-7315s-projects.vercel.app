// ============================================================
// SRS 5@5 - PARTICIPANT LIVE RESULT
// Uses the get_participant_view() database function, so the
// browser never reads the participants table directly.
// ============================================================

const STORAGE_KEY = "srs_participant_code";
const $ = id => document.getElementById(id);

let currentCode = "";
let currentRow = null;

try { currentCode = localStorage.getItem(STORAGE_KEY) || ""; } catch (e) {}


function showMessage(text, type) {
    const box = $("participantLoginMessage");
    box.textContent = text;
    box.className = "message show " + (type || "");
}

function clearMessage() {
    const box = $("participantLoginMessage");
    box.textContent = "";
    box.className = "message";
}

function ordinal(n) {
    if (n === null || n === undefined) return "--";
    const s = ["th", "st", "nd", "rd"], v = n % 100;
    return n + (s[(v - 20) % 10] || s[v] || s[0]);
}

function showLogin() {
    currentRow = null;
    $("resultSection").classList.add("hidden");
    $("loginSection").classList.remove("hidden");
}

function isRaceRunning() {
    return typeof RaceClock !== "undefined" && RaceClock.isRunning();
}


// Status box + big time. Runs on every clock tick, so a runner who has
// not finished yet sees the live race clock instead of "--".
function updateTimeDisplay() {
    if (!currentRow) return;

    const status = currentRow.status || "WAITING";
    const running = status === "WAITING" && isRaceRunning();
    const shownStatus = running ? "RUNNING" : status;

    $("statusBox").textContent = shownStatus;
    $("statusBox").className = "status status-" + shownStatus.toLowerCase();

    if (status === "FINISHED" && currentRow.result_time) {
        $("resultLabel").textContent = "RESULT TIME";
        $("resultTime").textContent = currentRow.result_time;
    } else if (running) {
        $("resultLabel").textContent = "RACE CLOCK";
        $("resultTime").textContent = RaceClock.format(RaceClock.elapsedMs());
    } else {
        $("resultLabel").textContent = "RESULT TIME";
        $("resultTime").textContent = "--";
    }

    // the certificate is only available once the runner has finished
    const canDownload = status === "FINISHED" && !!currentRow.result_time;
    const pdfButton = $("downloadPdfButton");

    if (pdfButton.disabled === canDownload) {
        pdfButton.disabled = !canDownload;
        pdfButton.textContent = canDownload ? "Download Certificate" : "Certificate available after you finish";
    }
}

function showResult(r) {
    currentRow = r;

    $("participantName").textContent = r.participant_name || "--";
    $("participantBib").textContent = r.bib || "--";
    $("participantGender").textContent = r.gender || "--";
    $("participantAgeCategory").textContent = r.age_category || "--";
    $("overallPosition").textContent = ordinal(r.position_rank);
    $("genderPosition").textContent = ordinal(r.gender_position);
    $("ageCategoryPosition").textContent = ordinal(r.age_category_position);
    $("liveUpdate").textContent =
        "Live \u2022 Updated " + new Date().toLocaleTimeString();

    updateTimeDisplay();

    $("loginSection").classList.add("hidden");
    $("resultSection").classList.remove("hidden");
}


async function loadResult(fromLogin) {
    if (!currentCode) return;

    const { data, error } = await supabaseClient.rpc(
        "get_participant_view",
        { p_code: currentCode }
    );

    if (error) {
        console.error("Participant lookup error:", error);
        if (fromLogin) {
            showMessage("Could not load your result. Please try again.", "error");
        }
        return;
    }

    const row = data && data[0];

    if (!row) {
        currentCode = "";
        try { localStorage.removeItem(STORAGE_KEY); } catch (e) {}
        showLogin();
        showMessage("Participant code not found.", "error");
        return;
    }

    clearMessage();
    showResult(row);
}


// ============================================================
// DOWNLOAD CERTIFICATE AS ONE PDF PAGE (jsPDF)
// ============================================================

// Loads an image from the site and returns it as a PNG data URL (null if missing)
function loadImage(src) {
    return new Promise(resolve => {
        const img = new Image();

        img.onload = () => {
            try {
                const canvas = document.createElement("canvas");
                canvas.width = img.naturalWidth;
                canvas.height = img.naturalHeight;
                canvas.getContext("2d").drawImage(img, 0, 0);

                resolve({
                    data: canvas.toDataURL("image/png"),
                    width: img.naturalWidth,
                    height: img.naturalHeight
                });
            } catch (e) {
                resolve(null);
            }
        };

        img.onerror = () => resolve(null);
        img.src = src;
    });
}


// Poster colours
const PDF_NEON = [212, 252, 14];
const PDF_WHITE = [255, 255, 255];
const PDF_GREY = [170, 175, 185];


// One landscape A4 page:
//   left 75%  = certificate of participation (+ sponsors)
//   right 25% = runner details + FINISHER
function addCertificatePage(doc, r, images) {
    const W = 297;
    const H = 210;
    const SPLIT = W * 0.75;                 // 222.75 mm
    const certCx = (6 + SPLIT) / 2;         // centre of the certificate area
    const panelCx = (SPLIT + (W - 6)) / 2;  // centre of the right panel
    const name = String(r.participant_name || "");

    const color = c => doc.setTextColor(c[0], c[1], c[2]);

    // ---- black background + right panel ----
    doc.setFillColor(0, 0, 0);
    doc.rect(0, 0, W, H, "F");

    doc.setFillColor(20, 22, 26);
    doc.rect(SPLIT, 6, W - 6 - SPLIT, H - 12, "F");

    // ---- neon frame + divider ----
    doc.setDrawColor(PDF_NEON[0], PDF_NEON[1], PDF_NEON[2]);
    doc.setLineWidth(0.8);
    doc.rect(6, 6, W - 12, H - 12);

    doc.setLineWidth(0.6);
    doc.line(SPLIT, 6, SPLIT, H - 6);


    // =====================================================
    // LEFT 75% - CERTIFICATE
    // =====================================================

    // header art (SRS logo + 5@5 + 5 KM RUN RACE)
    if (images.header) {
        const w = 58;
        const h = w * images.header.height / images.header.width;
        doc.addImage(images.header.data, "PNG", certCx - w / 2, 12, w, h);
    } else {
        doc.setFont("helvetica", "bold");
        doc.setFontSize(30);
        color(PDF_NEON);
        doc.text("SRS 5@5", certCx, 34, { align: "center" });
        doc.setFontSize(12);
        color(PDF_WHITE);
        doc.text("5 KM RUN RACE", certCx, 42, { align: "center" });
    }

    // title
    doc.setFont("helvetica", "bold");
    doc.setFontSize(21);
    color(PDF_WHITE);
    doc.text("CERTIFICATE OF PARTICIPATION", certCx, 66, { align: "center" });

    doc.setDrawColor(PDF_NEON[0], PDF_NEON[1], PDF_NEON[2]);
    doc.setLineWidth(1.2);
    doc.line(certCx - 28, 70, certCx + 28, 70);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(11);
    color(PDF_GREY);
    doc.text("This is to certify that", certCx, 80, { align: "center" });

    // name
    doc.setFont("helvetica", "bold");
    doc.setFontSize(name.length > 30 ? 20 : name.length > 22 ? 25 : 30);
    color(PDF_NEON);
    doc.text(name, certCx, 94, { align: "center" });

    doc.setDrawColor(70, 74, 82);
    doc.setLineWidth(0.4);
    doc.line(certCx - 70, 99, certCx + 70, 99);

    // event line
    doc.setFont("helvetica", "normal");
    doc.setFontSize(11);
    color(PDF_GREY);
    doc.text("has successfully participated in the", certCx, 109, { align: "center" });

    doc.setFont("helvetica", "bold");
    doc.setFontSize(15);
    color(PDF_WHITE);
    doc.text("SRS 5@5  |  5 KM RUN RACE", certCx, 118, { align: "center" });

    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    color(PDF_GREY);
    doc.text("Friday, 2 October 2026  -  5 AM", certCx, 126, { align: "center" });
    doc.text("Shaab Swimming Pool Complex", certCx, 132, { align: "center" });

    doc.setFont("helvetica", "bold");
    doc.setFontSize(8.5);
    color(PDF_NEON);
    doc.text("A FASTER YOU   *   A STRONGER COMMUNITY", certCx, 140, { align: "center" });

    // signature line
    doc.setDrawColor(110, 115, 125);
    doc.setLineWidth(0.4);
    doc.line(certCx - 30, 154, certCx + 30, 154);

    // race director name (printed above the signature line)
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    color(PDF_WHITE);
    doc.text("JUAN AWA", certCx, 151.5, { align: "center" });

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);
    color(PDF_GREY);
    doc.text("Race Director", certCx, 159, { align: "center" });

    // sponsors
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7.5);
    color(PDF_NEON);
    doc.text("SUPPORTING PARTNERS", certCx, 165, { align: "center" });

    if (images.sponsors) {
        const w = 150;
        const h = w * images.sponsors.height / images.sponsors.width;
        doc.addImage(images.sponsors.data, "PNG", certCx - w / 2, 167.5, w, h);
    } else {
        doc.setFont("helvetica", "bold");
        doc.setFontSize(12);
        color(PDF_WHITE);
        doc.text("Fursaaa   |   SUFFIX   |   PRO SPORTS   |   Bliss", certCx, 182, { align: "center" });
    }


    // =====================================================
    // RIGHT 25% - RUNNER DETAILS
    // =====================================================

    const left = panelCx - 29;
    const right = panelCx + 29;

    // participant name
    const nameSize = name.length > 24 ? 13 : 16;

    doc.setFont("helvetica", "bold");
    doc.setFontSize(nameSize);
    color(PDF_WHITE);

    const nameLines = doc.splitTextToSize(name, 58);

    doc.text(nameLines, panelCx, 44, { align: "center", lineHeightFactor: 1.15 });

    let y = 44 + nameLines.length * nameSize * 0.5 + 4;

    doc.setDrawColor(PDF_NEON[0], PDF_NEON[1], PDF_NEON[2]);
    doc.setLineWidth(1);
    doc.line(panelCx - 10, y, panelCx + 10, y);

    y += 15;

    // bib number, gender, age category
    [
        ["BIB NUMBER", r.bib],
        ["GENDER", r.gender],
        ["AGE CATEGORY", r.age_category]
    ].forEach(row => {
        doc.setFont("helvetica", "bold");
        doc.setFontSize(8);
        color(PDF_GREY);
        doc.text(row[0], left, y);

        doc.setFontSize(14);
        color(PDF_WHITE);
        doc.text(String(row[1] || "--"), right, y, { align: "right" });

        doc.setDrawColor(55, 59, 66);
        doc.setLineWidth(0.3);
        doc.line(left, y + 3.5, right, y + 3.5);

        y += 14;
    });

    // FINISHER (big neon green text)
    y += 6;

    doc.setFont("helvetica", "bold");
    doc.setFontSize(31);
    color(PDF_NEON);
    doc.text("FINISHER", panelCx, y + 20, { align: "center" });

    // RUN . CONNECT . BELONG (sized to fill the panel width)
    const tagline = "RUN  .  CONNECT  .  BELONG";

    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);

    const tagSize = Math.min(12.5, 10 * 60 / doc.getTextWidth(tagline));

    doc.setDrawColor(PDF_NEON[0], PDF_NEON[1], PDF_NEON[2]);
    doc.setLineWidth(0.8);
    doc.line(panelCx - 10, H - 27, panelCx + 10, H - 27);

    doc.setFontSize(tagSize);
    color(PDF_NEON);
    doc.text(tagline, panelCx, H - 18, { align: "center" });
}


function buildResultPdf(JsPDF, r, images) {
    const doc = new JsPDF({ unit: "mm", format: "a4", orientation: "landscape" });

    addCertificatePage(doc, r, images);

    return doc;
}


async function downloadPdf() {
    const r = currentRow;

    if (!r || r.status !== "FINISHED" || !r.result_time) return;

    const JsPDF = window.jspdf && window.jspdf.jsPDF;

    if (!JsPDF) {
        alert("The PDF tool could not load. Check your internet connection and try again.");
        return;
    }

    const button = $("downloadPdfButton");
    button.disabled = true;
    button.textContent = "Preparing certificate...";

    try {
        const [header, sponsors] = await Promise.all([
            loadImage("cert-header.png"),
            loadImage("cert-sponsors.png?v=2")
        ]);

        const doc = buildResultPdf(JsPDF, r, { header: header, sponsors: sponsors });

        const safeName = String(r.participant_name || "")
            .replace(/[^a-z0-9]+/gi, "-")
            .replace(/^-+|-+$/g, "") || "Participant";

        doc.save("SRS-5at5-Certificate-Bib" + (r.bib || "") + "-" + safeName + ".pdf");
    } catch (error) {
        console.error("PDF error:", error);
        alert("Could not create the certificate. Please try again.");
    } finally {
        button.disabled = false;
        button.textContent = "Download Certificate";
    }
}

$("downloadPdfButton").addEventListener("click", downloadPdf);


$("participantLoginForm").addEventListener("submit", async e => {
    e.preventDefault();
    currentCode = $("participantCodeInput").value.trim();
    if (!currentCode) return;

    try { localStorage.setItem(STORAGE_KEY, currentCode); } catch (err) {}

    showMessage("Looking up your result...", "");
    await loadResult(true);
});

$("changeParticipantButton").addEventListener("click", () => {
    currentCode = "";
    try { localStorage.removeItem(STORAGE_KEY); } catch (e) {}
    $("participantCodeInput").value = "";
    clearMessage();
    showLogin();
});


// Live updates: refresh whenever a result changes, plus a safety-net refresh
let reloadTimer = null;

supabaseClient
    .channel("participant-live-results")
    .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "race_results" },
        () => {
            clearTimeout(reloadTimer);
            reloadTimer = setTimeout(() => loadResult(false), 250);
        }
    )
    .subscribe();

setInterval(() => loadResult(false), 10000);


// Race clock (live timer for runners still on the course)
if (typeof RaceClock !== "undefined") {
    RaceClock.onTick(updateTimeDisplay);
    RaceClock.init();
}

$("participantCodeInput").value = currentCode;
loadResult(false);