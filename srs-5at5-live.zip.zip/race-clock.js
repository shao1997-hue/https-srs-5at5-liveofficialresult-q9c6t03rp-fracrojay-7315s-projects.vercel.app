// ============================================================
// SRS 5@5 - SHARED RACE CLOCK
// Server-synced race timer used by the organizer, spectator and
// participant pages. Load supabase-config.js BEFORE this file.
//
// - The start time lives in the race_state table (set by the server).
// - Every device measures its own clock offset against the server,
//   so all screens show the same time even if phone clocks differ.
// ============================================================

var RaceClock = (function () {

    var state = { status: "NOT_STARTED", start_ms: null, end_ms: null };
    var offsetMs = 0;
    var started = false;
    var hasLoaded = false;
    var changeCallbacks = [];
    var tickCallbacks = [];

    var STATUS_TEXT = {
        NOT_STARTED: "WAITING TO START",
        RUNNING: "RACE IN PROGRESS",
        ENDED: "CLOCK STOPPED"
    };


    function pad(n) {
        return String(n).padStart(2, "0");
    }


    // 0:24:35 style
    function format(ms) {
        var total = Math.max(0, Math.floor(ms / 1000));
        var h = Math.floor(total / 3600);
        var m = Math.floor((total % 3600) / 60);
        var s = total % 60;
        return h + ":" + pad(m) + ":" + pad(s);
    }


    function elapsedMs() {
        if (state.start_ms === null) {
            return 0;
        }
        if (state.status === "RUNNING") {
            return Date.now() + offsetMs - state.start_ms;
        }
        if (state.status === "ENDED" && state.end_ms !== null) {
            return state.end_ms - state.start_ms;
        }
        return 0;
    }


    // Measure (server time - this device's time). The sample with the
    // shortest round trip is the most accurate, so take the best of 4.
    async function syncOffset() {
        var best = null;

        for (var i = 0; i < 4; i++) {
            try {
                var t0 = Date.now();
                var res = await supabaseClient.rpc("server_time");
                var t1 = Date.now();

                if (res.error || res.data === null || res.data === undefined) {
                    continue;
                }

                var rtt = t1 - t0;
                var off = Number(res.data) - (t0 + rtt / 2);

                if (best === null || rtt < best.rtt) {
                    best = { rtt: rtt, off: off };
                }
            } catch (e) {
                // ignore, try again
            }
        }

        if (best !== null) {
            offsetMs = best.off;
        }
    }


    function updateStatusText() {
        var text = STATUS_TEXT[state.status] || "";
        document.querySelectorAll("[data-race-status]").forEach(function (el) {
            el.textContent = text;
            el.setAttribute("data-state", state.status);
        });
    }


    function tick() {
        var text = format(elapsedMs());

        document.querySelectorAll("[data-race-clock]").forEach(function (el) {
            if (el.textContent !== text) {
                el.textContent = text;
            }
        });

        tickCallbacks.forEach(function (cb) {
            try { cb(); } catch (e) { console.error(e); }
        });
    }


    async function loadState() {
        try {
            var res = await supabaseClient
                .from("race_state")
                .select("status,start_ms,end_ms")
                .eq("id", 1)
                .maybeSingle();

            if (res.error) {
                throw res.error;
            }

            var d = res.data || {};

            var next = {
                status: d.status || "NOT_STARTED",
                start_ms: d.start_ms === null || d.start_ms === undefined ? null : Number(d.start_ms),
                end_ms: d.end_ms === null || d.end_ms === undefined ? null : Number(d.end_ms)
            };

            var changed =
                next.status !== state.status ||
                next.start_ms !== state.start_ms ||
                next.end_ms !== state.end_ms;

            var firstLoad = !hasLoaded;

            hasLoaded = true;
            state = next;

            updateStatusText();
            tick();

            if (changed || firstLoad) {
                changeCallbacks.forEach(function (cb) {
                    try { cb(state); } catch (e) { console.error(e); }
                });
            }
        } catch (error) {
            console.error("Race clock load error:", error);
        }
    }


    async function init() {
        if (started) {
            return;
        }
        started = true;

        updateStatusText();
        setInterval(tick, 200);

        await syncOffset();
        await loadState();

        supabaseClient
            .channel("race-clock-state")
            .on(
                "postgres_changes",
                { event: "*", schema: "public", table: "race_state" },
                function () { loadState(); }
            )
            .subscribe();

        // Safety nets in case realtime drops
        setInterval(loadState, 15000);
        setInterval(syncOffset, 60000);

        document.addEventListener("visibilitychange", function () {
            if (!document.hidden) {
                syncOffset().then(loadState);
            }
        });
    }


    return {
        init: init,
        refresh: loadState,
        format: format,
        elapsedMs: elapsedMs,
        getState: function () { return state; },
        isRunning: function () { return state.status === "RUNNING"; },
        onChange: function (cb) { changeCallbacks.push(cb); },
        onTick: function (cb) { tickCallbacks.push(cb); }
    };

})();